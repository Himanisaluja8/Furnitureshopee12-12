import React from 'react';
import './footer.css';
import { Container, Row, Col, ListGroup, ListGroupItem } from 'reactstrap';
import logo from '../../assets/images/eco-logo.png'
import { Link } from 'react-router-dom';

//Footer------------------------------------------------------------------------------------
const Footer = () => {

    // Display year for Copyright

    const year = new Date().getFullYear();
    return <footer className="footer">
        <Container>
            <Row>
                <Col lg='4'>
                
                <div className="logo">
                    
                    <div>
                        <h1 className='text-white'>furnitureshopee</h1>
                    </div>
                </div>
                <p className='footer__text mt-4'> 
                We are your one-stop destination for all your home décor needs. 
                Our mission is to provide high-quality furniture and 
                home décor items that help you transform your living spaces into your dream home.
                        </p>
                </Col>
                <Col lg='3'>
                    <div className="footer__quick-links">
                        <h4 className="quick__links-title">
                            Top Categories
                        </h4>
                        <ListGroup className='mb-3'>
                            <ListGroupItem className='ps-0 border-0'>
                                <Link to='#'>BEDS AND MATTRESSES</Link>
                            </ListGroupItem>

                            <ListGroupItem className='ps-0 border-0'>
                            <Link to='#'>SOFAS AND RECLINERS</Link>
                            </ListGroupItem>

                            <ListGroupItem className='ps-0 border-0'>
                            <Link to='#'>LIVING</Link>
                            </ListGroupItem>

                            <ListGroupItem className='ps-0 border-0'>
                            <Link to='#'>DINING</Link>
                            </ListGroupItem>

                            <ListGroupItem className='ps-0 border-0'>
                            <Link to='#'>HOMEWARES</Link>
                            </ListGroupItem>
                        </ListGroup>
                    </div>
                </Col>
                <Col lg='2'>
                <div className="footer__quick-links">
                        <h4 className="quick__links-title">
                            Useful Links
                        </h4>
                        <ListGroup className='mb-3'>

                            <ListGroupItem className='ps-0 border-0'>
                            <Link to='#'>Admin Login</Link>
                            </ListGroupItem>

                            <ListGroupItem className='ps-0 border-0'>
                            <Link to="/Paymentpage">Payment Options</Link>
                            </ListGroupItem>

                            <ListGroupItem className='ps-0 border-0'>
                            <Link to="/Winz">Winz Quote</Link>
                            </ListGroupItem>

                            <ListGroupItem className='ps-0 border-0'>
                            <Link to='/Privacy'>Privacy Policy</Link>
                            </ListGroupItem>
                        </ListGroup>
                    </div>
                </Col>
                <Col lg='3'>
                <div className="footer__quick-links">
                        <h4 className="quick__links-title">
                            Contact Info
                        </h4>
                        <ListGroup className='footer__contact'>
                            <ListGroupItem className='ps-0 border-0 d-flex align-items-centre gap-2'>
                                <span><i class="ri-map-pin-line"></i></span>
                                <p>Furniture Shopee
                                Shop C2, 459 Roscommon
                                Clendon Park New Zealand, Auckland</p>
                            </ListGroupItem>

                            <ListGroupItem className='ps-0 border-0 d-flex align-items-centre gap-2'>
                            <span><i class="ri-phone-line"></i></span>
                            <p>+ 64 22 063 7040</p>
                            </ListGroupItem>

                            <ListGroupItem className='ps-0 border-0 d-flex align-items-centre gap-2'>
                            <span><i class="ri-phone-line"></i></span>
                            <p>furnitureshopee@hotmail.com</p>
                            </ListGroupItem>

                            
                        </ListGroup>
                    </div>
                </Col>

                <Col lg='12'>
                    <p className="footer__copyright">
                        Copyright {year} All rights reserved.
                    </p>
                </Col>

            </Row>

        </Container>
        </footer>
};

export default Footer;
