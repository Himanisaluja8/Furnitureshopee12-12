import React from 'react';
import { Navbar, Nav,  Container } from 'react-bootstrap';
import { BrowserRouter as Router, Link, Route, Routes } from 'react-router-dom';


function NavBar() {
  return (
 
    <div className="navigation">             
                 <div>
      <Navbar classname ="nav-one">
        <Navbar.Brand as={Link} to="/">PRODUCTS</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto">
            <Nav.Link as={Link} to="/Bedndmat">BEDS AND MATTRESSES</Nav.Link>
            <Nav.Link as={Link} to="/">SOFAS AND RECLINERS</Nav.Link>
            <Nav.Link as={Link} to="/">LIVING</Nav.Link>
            <Nav.Link as={Link} to="/">DINING</Nav.Link>
            <Nav.Link as= {Link} to ="/">HOMEWARES</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
      </div>
                </div> 
  );
}

export default NavBar;