import React from 'react';
import { Container, Row, Col } from 'reactstrap';
import winzq from '../assets/images/Winz Quote.jpg';
import Img from '../assets/images/WINZ_quote.png';
import "../styles/home.css";

const Winz = () => {
  

    return (
<Container className="Winz_quotes">
            <Row>
            <div className="winz">
                            <img src={winzq} alt="winz_quote" />
                        </div>
               <div >
                <p > 
                Our company is happy to provide Work and Income Quote. We are an approved supplier for Work and Income New Zealand. 
                We will arrange either a pick-up or delivery of your requested items once we received payment.
                        </p>
                        </div>
                        <div className="winz">
                            <img src={Img} alt="winz_quote" />
                        </div>
                
              </Row>
                </Container>
  
    ) 
};
export default Winz