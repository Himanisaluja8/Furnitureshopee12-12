import react from 'react';

const Cart = () => {
    return (
        <div>
           Cart
        </div>
    );
}

export default Cart;
