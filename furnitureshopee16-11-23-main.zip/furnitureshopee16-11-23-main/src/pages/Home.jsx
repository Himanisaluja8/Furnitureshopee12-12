import React from 'react';  
import { Link } from 'react-router-dom';

//motion for button
//import {motion} from 'react-motion';

import Helmet from '../components/Helmet/Helmet';
import "../styles/home.css";

import heroImg from '../assets/images/winz.jpeg';



import { Container, Row, Col } from 'reactstrap';
import { useState } from 'react';


const Home = () => {

    const year = new Date().getFullYear();
    const [email, setEmail] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(false);

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handleTermsChange = (e) => {
    setAcceptTerms(e.target.checked);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Perform your sign-up logic here, e.g., send data to a server

    // Reset form fields
    setEmail('');
    setAcceptTerms(false);
  };



    return <Helmet title={"Home"}>
        <section className="hero__section">
         <Container>
            <Row>     
                        <div className="hero__img">
                            <img src={heroImg} alt="hero" />
                        </div>
                       
            </Row>
         </Container>

        </section>
        <Container>
            <Col>
            <form onSubmit={handleSubmit}>
      <label>
        Sign up to receive the exclusive news & offers*
        <input
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={handleEmailChange}
          required
        />
      </label>

    

    </form>
            </Col>
        </Container>
    </Helmet>;
};
export default Home;
